import * as THREE from "./three.module.js";
import {OrbitControls} from "./OrbitControls.js"
import {FirstPersonControls} from "./FirstPersonControls.js"
import {PointerLockControls} from "./PointerLockControls.js";
import {GLTFLoader} from "./GLTFLoader.js";
import {CharacterControls} from './characterControls.js';

var scene, camera, renderer, controls;
var diamond, ground; 
var directionalLight, ambientLight;
var model;

//for the maze 
const bsize = 5;
const tombWallTexture = new THREE.MeshLambertMaterial({color: "rgb(34,139,34)"});
const tombWall = new THREE.BoxBufferGeometry(bsize,10,bsize);

var amaze = [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1],
    [1,0,1,1,1,1,0,0,0,1,0,0,0,0,0,0,1],
    [1,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,1,0,0,0,1,1,1,1,0,1],
    [1,0,0,1,1,1,0,1,1,1,1,1,0,0,0,0,1],
    [1,1,1,1,1,1,0,0,0,0,0,1,0,1,1,1,1],
    [1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1],
    [1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1],
    [1,0,0,1,0,1,1,1,1,0,0,1,0,1,1,1,1],
    [1,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,1],
    [1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
  ];

//for the skybox 
var skyBox;

var cam2;
let iw, ih;

var clock = new THREE.Clock();
var characterControls;
const keysPressed = {};

function animate(){

    requestAnimationFrame(animate);

    let mixerUpdateDelta = clock.getDelta();
    if (characterControls) {
        characterControls.update(mixerUpdateDelta, keysPressed);
    }
    controls.update();

    diamond.rotation.x += 0.02;
    diamond.rotation.y -= 0.02;
    diamond.rotation.z += 0.02;

    //speed of the skybox rotations
    skyBox.rotation.y += 0.001;

    //getMaze.rotation.y += 0.001;

    renderer.render(scene, camera);

    // renderer.clearDepth();
    // renderer.setScissorTest(true);
    // renderer.setScissor(
    //     window.innerWidth - iw - 16,
    //     window.innerHeight - ih - 16,
    //     iw,
    //     ih
    // );
    // renderer.setViewport(
    //     window.innerWidth - iw - 16,
    //     window.innerHeight - ih - 16,
    //     iw,
    //     ih
    // );

    // renderer.render(scene, cam2);
    // renderer.setScissorTest(false);
}

function getDiamond(){
    const geometry = new THREE.ConeGeometry(2, 5, 6);
    const material = new THREE.MeshStandardMaterial({
        color: 0xff00ff,
        metalness: 1,
        roughness:0.5
    });
    const cone = new THREE.Mesh(geometry, material);

    cone.rotation.x = Math.PI;

    const geometryB = new THREE.ConeGeometry(2, 2, 6);
    const materialB = new THREE.MeshStandardMaterial({
        color: 0xff00ff,
        metalness: 1,
        roughness:0.5
    });
    const coneB = new THREE.Mesh(geometryB, materialB);

    coneB.rotation.x = Math.PI;
    coneB.position.y = -3.5;

    cone.castShadow = true;
    cone.receiveShadow = true;

    cone.add(coneB);

    return cone;
}

function getTree(){
    // var texture = new THREE.TextureLoader().load(["bark.jpg"])

    // const geometry = new THREE.CylinderGeometry(10, 10, 150, 50, 1);
    // const material = new THREE.MeshStandardMaterial({map: texture});
    // const mesh = new THREE.Mesh(geometry, material);

    const geometryPlane = new THREE.PlaneGeometry(30, 150);
    const materialPlane = new THREE.MeshBasicMaterial({
        visible: false
    });
    const meshPlane = new THREE.Mesh(geometryPlane, materialPlane);

    // mesh.add(meshPlane);

    // const geometryB = new THREE.IcosahedronGeometry(20, 0);
    // const materialB = new THREE.MeshStandardMaterial({color: 0x00ff00});
    // const meshB = new THREE.Mesh(geometryB, materialB);
    // meshB.position.y = 75;
    // meshB.castShadow = true;
    // meshB.receiveShadow = true;

    // const geometryC = new THREE.DodecahedronGeometry(20, 0);
    // const materialC = new THREE.MeshStandardMaterial({color: 0x028a0f});
    // const meshC = new THREE.Mesh(geometryC, materialC);
    // meshC.position.y = 75;
    // meshC.castShadow = true;
    // meshC.receiveShadow = true;

    // const geometryD = new THREE.ConeGeometry(20, 50, 64);
    // const materialD = new THREE.MeshStandardMaterial({color: 0x234f1e});
    // const meshD = new THREE.Mesh(geometryD, materialD);
    // meshD.position.y = 75;
    // meshD.castShadow = true;
    // meshD.receiveShadow = true;
    

    // var r = Math.floor(Math.random() * 3);
    // if (r == 0){
    //     mesh.add(meshB);
    // }
    // else if (r == 1){
    //     mesh.add(meshC);
    // }
    // else{
    //     mesh.add(meshD);
    // }

    // mesh.castShadow = true;
    // mesh.receiveShadow = true;

    return meshPlane;
}

function getBush(){
    var texture = new THREE.TextureLoader().load(["512x_foliage_coarse01.png"])

    var mesh = new THREE.Mesh(
        new THREE.BoxGeometry(53, 100, 10),
        new THREE.MeshStandardMaterial({map: texture})
    );
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    return mesh;
}

function getGround(q,w){
    var texture = new THREE.TextureLoader().load(["512x_foliage_coarse01.png"])

    var mesh = new THREE.Mesh(
        new THREE.PlaneGeometry(q,w),
        new THREE.MeshStandardMaterial({map: texture})
    );
    mesh.rotation.x = -Math.PI/2;
    mesh.receiveShadow = true;
    return mesh;
}

function getSkybox()
{

    let materialArray = [];

    let tex_ft = new THREE.TextureLoader().load("posx.jpg");
    let tex_bk = new THREE.TextureLoader().load("negx.jpg");
    let tex_up = new THREE.TextureLoader().load("posy.jpg");
    let tex_dn = new THREE.TextureLoader().load("negy.jpg");
    let tex_rt = new THREE.TextureLoader().load("posz.jpg");
    let tex_lf = new THREE.TextureLoader().load("negz.jpg");

    materialArray.push(new THREE.MeshBasicMaterial({map: tex_ft}));

    materialArray.push(new THREE.MeshBasicMaterial({map: tex_bk}));

    materialArray.push(new THREE.MeshBasicMaterial({map: tex_up}));

    materialArray.push(new THREE.MeshBasicMaterial({map: tex_dn}));

    materialArray.push(new THREE.MeshBasicMaterial({map: tex_rt}));

    materialArray.push(new THREE.MeshBasicMaterial({map: tex_lf}));

    for (let i = 0; i < 6; i++) {
        materialArray[i].side = THREE.BackSide;
    }
    
    let skyBoxGeo = new THREE.BoxGeometry(1200,1200,1200);
    let skyBox = new THREE.Mesh(skyBoxGeo, materialArray);
    return skyBox;

}

//FUNCTIONS TO MAKE THE MAZE #####################################
/*function getGround(q,w){
    var texture = new THREE.TextureLoader().load(["snow01.png"])

    var mesh = new THREE.Mesh(
        new THREE.PlaneGeometry(q,w),
        new THREE.MeshStandardMaterial({map: texture})
    );
    mesh.rotation.x = -Math.PI/2;
    mesh.receiveShadow = true;
    return mesh;
}*/ //theres currently two ground functions not fun and fresh


function makeWall(){
    var wall = new THREE.Mesh(tombWall,tombWallTexture);
    return wall;
  }
  
function getMaze(){
    var maze = new THREE.Object3D();
    for(let r=0;r<14;r++){
      for(let c=0;c<17;c++){
        if(amaze[r][c]==1){
          var wall = new makeWall();
          wall.position.set(r*5,5,c*5);
          maze.add(wall);
        }
      }
    }
    //maze.add(wall);
    return maze;
  }


function init(){
    window.addEventListener(
        "resize",
        function(){
            camera.aspect = this.innerWidth/this.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(this.innerWidth, this.innerHeight);

            iw = this.window.innerWidth/4;
            ih = this.window.innerHeight/4;

            cam2.aspect = iw/ih;
            cam2.updateProjectionMatrix();
        }
    )

    scene = new THREE.Scene();

    //scene.fog = new THREE.FogExp2(0xdddddd, 0.005);

    //Renderer **************************************************************************************
    renderer = new THREE.WebGLRenderer({antialias:true});
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    document.body.appendChild(renderer.domElement);

    //Camera **************************************************************************************
    camera = new THREE.PerspectiveCamera(
        60, window.innerWidth/window.innerHeight,
        0.1,
        1000
    );


    //for it to be behind the soldier (0,30,35)
    camera.position.set(0,300,0);
    //camera.lookAt(0,0,-20);

    // cam2 = new THREE.PerspectiveCamera(
    //     90,
    //     window.innerWidth/window.innerHeight,
    //     0.01,
    //     500
    // );
    // cam2.position.set(0,200,0);
    // cam2.lookAt(0,0,0);

    // cam2.name = "mapCamera";

    // camera.add(cam2);

    // scene.add(camera);

    // const h = new THREE.CameraHelper( cam2 );
    // scene.add( h );


    // ADDING MUSIC ################################################
    const listener = new THREE.AudioListener();
    camera.add(listener);

    //audio loader (loads all mp3 files)
    const audioLoader = new THREE.AudioLoader();

    //for the background sound
    //creates a nonpositional global audio object
    const bgSound = new THREE.Audio(listener);
    scene.add(bgSound);

    //load the sound files
    audioLoader.load('../sounds/Wii Music - Background Music.mp3', function( buffer ) {
        bgSound.setBuffer( buffer );
        bgSound.setLoop( true );  //sound will repeat 
        bgSound.setVolume( 0.4 ); //volume is 0-1

        //bgSound.play(); //starts the sound now
    });

    //SkyBox **************************************************************************************
    skyBox = getSkybox();
    scene.add(skyBox);
    
    /*var skybox = new THREE.CubeTextureLoader().load([
    "posx.jpg",
    "negx.jpg",
    "posy.jpg",
    "negy.jpg",
    "posz.jpg",
    "negz.jpg"]);

    scene.background = skybox;*/

    //Controls **************************************************************************************
    controls = new OrbitControls(camera, renderer.domElement);

    /*controls.enableDamping = true;
    controls.minDistance = 30;
    controls.maxDistance = 45;
    controls.enablePan = false;*/
    //controls.maxPolarAngle = Math.PI/2 - 0.05

    //Lighting **************************************************************************************
    ambientLight = new THREE.AmbientLight(0xffffff);
    ambientLight.intensity = 0.1;
    scene.add(ambientLight);

    directionalLight = new THREE.DirectionalLight(0xffffff);
    directionalLight.intensity = 0.7;
    directionalLight.position.set(5,200,5);
    directionalLight.castShadow = true;

    var d = 1000;

    directionalLight.shadow.mapSize.width = 8192; 
    directionalLight.shadow.mapSize.height = 8192;
    directionalLight.shadow.camera.near = 0.5; // default
    directionalLight.shadow.camera.far = 1000;
    directionalLight.shadow.camera.right = d
    directionalLight.shadow.camera.left = -d
    directionalLight.shadow.camera.top = d
    directionalLight.shadow.camera.bottom = -d

    scene.add(directionalLight);
    
    //Player ************************************************************************************

    // MODEL WITH ANIMATIONS
    /*
    new GLTFLoader().load('./Soldier.glb', function (gltf) {
        model = gltf.scene;
        model.traverse(function (object) {
            if (object.isMesh)
                object.castShadow = true;
        });
        model.scale.set(10, 10, 10);
        scene.add(model);
        const gltfAnimations = gltf.animations;
        const mixer = new THREE.AnimationMixer(model);
        const animationsMap = new Map();
        gltfAnimations.filter(a => a.name != 'TPose').forEach((a) => {
            animationsMap.set(a.name, mixer.clipAction(a));
        }); 
        characterControls = new CharacterControls(model, mixer, animationsMap, controls, camera, 'Idle');
    });
    // CONTROL KEYS
    
    document.addEventListener('keydown', (event) => {
        if (event.shiftKey && characterControls) {
            characterControls.switchRunToggle();
        }
        else {
            keysPressed[event.key.toLowerCase()] = true;
        }
    }, false);
    document.addEventListener('keyup', (event) => {
        keysPressed[event.key.toLowerCase()] = false;
    }, false);
    */

    //Objects **************************************************************************************
    ground = getGround(1200,1200);  //ground
    scene.add(ground);

    diamond = getDiamond(); //tepmorary diamond
    diamond.scale.set(3,3,3);
    diamond.position.set(0,3,0);
    scene.add(diamond);


    let maze = getMaze();
    maze.scale.set(10,10,10);

    //positive x is right 
    //negative z is up 
    maze.position.set(-300,0,-400); //scale and move the maze
    scene.add(maze);

    //outside walls*************************************************************************
    /*for (var i = -500; i <= 500; i=i+25){ //trees
         var treeB = getTree();
         if (!(i >= -25 && i <= 25)){
             treeB.position.set(i, 75, 500);
             scene.add(treeB);
         }


         var treeT = getTree();
         treeT.position.set(i, 75, -500);
         scene.add(treeT);

         var treeR = getTree();
         treeR.position.set(500, 75, i);
         treeR.rotation.y = Math.PI/2;
         scene.add(treeR);

         var treeL = getTree();
         treeL.position.set(-500, 75, i);
         treeL.rotation.y = Math.PI/2;
         scene.add(treeL);
     }*/


    animate();
}

init();