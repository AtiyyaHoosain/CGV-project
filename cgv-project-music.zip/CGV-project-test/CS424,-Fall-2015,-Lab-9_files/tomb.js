import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.118.1/build/three.module.js';

/*import {first_person_camera} from './first-person-camera.js';
import {entity_manager} from './entity-manager.js';
import {player_entity} from './player-entity.js'
import {entity} from './entity.js';
import {player_input} from './player-input.js';
import {spatial_hash_grid} from './spatial-hash-grid.js';
import {ui_controller} from './ui-controller.js';
import {spatial_grid_controller} from './spatial-grid-controller.js';
import {attack_controller} from './attacker-controller.js';*/

class InLovingMemoryDemo {
  constructor() {
    this._Initialize();
  }

  _Initialize() {
    this._threejs = new THREE.WebGLRenderer({
      antialias: true,
    });

    this._threejs.outputEncoding = THREE.sRGBEncoding;
    this._threejs.gammaFactor = 2.2;
    this._threejs.shadowMap.enabled = true;
    this._threejs.shadowMap.type = THREE.PCFSoftShadowMap;
    this._threejs.setPixelRatio(window.devicePixelRatio);
    this._threejs.setSize(window.innerWidth, window.innerHeight);
    this._threejs.domElement.id = 'threejs';

    //document.getElementById('container').appendChild(this._threejs.domElement);

    window.addEventListener('resize', () => {
      this._OnWindowResize();
    }, false);

    const fov = 60;
    const aspect = 1920 / 1080;
    const near = 1.0;
    const far = 10000.0;
    this._camera = new THREE.PerspectiveCamera(fov, aspect, near, far);
    this._camera.position.set(25, 10, 25);

    this._scene = new THREE.Scene();
  
    this._scene.background = new THREE.Color(0xFFFFFF);
    this._scene.fog = new THREE.FogExp2(0x89b2eb, 0.002);

    let light = new THREE.DirectionalLight(0xFFFFFF, 1.0);
    /*
    light.position.set(-10, 500, 10);
    light.target.position.set(0, 0, 0);
    light.castShadow = true;
    light.shadow.bias = -0.001;
    light.shadow.mapSize.width = 4096;
    light.shadow.mapSize.height = 4096;
    light.shadow.camera.near = 0.1;
    light.shadow.camera.far = 1000.0;
    light.shadow.camera.left = 100;
    light.shadow.camera.right = -100;
    light.shadow.camera.top = 100;
    light.shadow.camera.bottom = -100; */

    this._scene.add(light);

    this._sun = light;

//#################################################################
function getDiamond(x,y,z){
  const geometry = new THREE.ConeGeometry(2, 5, 6);
  const material = new THREE.MeshStandardMaterial({color: 0xff00ff});
  const cone = new THREE.Mesh(geometry, material);

  cone.rotation.x = Math.PI;

  const geometryB = new THREE.ConeGeometry(2, 2, 6);
  const materialB = new THREE.MeshStandardMaterial({color: 0xff00ff});
  const coneB = new THREE.Mesh(geometryB, materialB);

  coneB.rotation.x = Math.PI;
  coneB.position.y = -3.5;

  cone.add(coneB);

  return cone;
}

const bsize = 5;
const tombWallTexture = new THREE.MeshLambertMaterial({color: "rgb(237,194,76)"});
const tombWall = new THREE.BoxBufferGeometry(bsize,10,bsize);

var amaze = [
  [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
  [1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1],
  [1,0,1,1,1,1,0,0,0,1,0,0,0,0,0,0,1],
  [1,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,1],
  [1,0,0,0,0,0,0,1,0,0,0,1,1,1,1,0,1],
  [1,0,0,1,1,1,0,1,1,1,1,1,0,0,0,0,1],
  [1,1,1,1,1,1,0,0,0,0,0,1,0,1,1,1,1],
  [1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1],
  [1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,0,1],
  [1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1],
  [1,0,0,1,0,1,1,1,1,0,0,1,0,1,1,1,1],
  [1,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,1],
  [1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1],
  [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
];

function makeWall(){
  var wall = new THREE.Mesh(tombWall,tombWallTexture);
  return wall;
}

function getMaze(){
  var maze = new THREE.Object3D();
  for(let r=0;r<14;r++){
    for(let c=0;c<17;c++){
      if(amaze[r][c]==1){
        var wall = new makeWall();
        wall.position.set(r*5,5,c*5);
        maze.add(wall);
      }
    }
  }
  //maze.add(wall);
  return maze;
}

function getRoof(){
    var roof = new makeWall();
    roof.scale.set(14,0.2,17);
    roof.position.set(14*2+5,10,17*2+5);
    return roof;
}

function getBase(){
  var mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(5000,5000),
      new THREE.MeshStandardMaterial({color: "rgb(237,194,76)"})
  );
  mesh.rotation.x = -Math.PI/2;
  mesh.receiveShadow = true;
  mesh.castShadow = false;
  return mesh;
}
//#################################################################

//Objects **************************************************************************************
    let base = getBase();  //tomb
    this._scene.add(base);

    let roof = getRoof();
    roof.castShadow = true;
    this._scene.add(roof);

    let maze = getMaze();
    this._scene.add(maze);

    let diamond = getDiamond(2,2,2); //temporary diamond
    diamond.position.set(0,3,0);
    diamond.castShadow = true;
    diamond.receiveShadow = true;
    this._scene.add(diamond);

    //this._entityManager = new entity_manager.EntityManager();
    /*this._grid = new spatial_hash_grid.SpatialHashGrid(
        [[-1000, -1000], [1000, 1000]], [100, 100]);

    this._LoadControllers();
    this._LoadPlayer();

    this._previousRAF = null;
    this._RAF();*/
  }

  _LoadControllers() {
    const ui = new entity.Entity();
    ui.AddComponent(new ui_controller.UIController());
    this._entityManager.Add(ui, 'ui');
  }

  /*
  _LoadPlayer() {
    const params = {
      camera: this._camera,
      scene: this._scene,
    };


    const player = new entity.Entity();
    player.AddComponent(new player_input.BasicCharacterControllerInput(params));
    player.AddComponent(new player_entity.BasicCharacterController(params));

    player.AddComponent(
        new spatial_grid_controller.SpatialGridController({grid: this._grid}));
    player.AddComponent(new attack_controller.AttackController({timing: 0.7}));
    this._entityManager.Add(player, 'player');

    const camera = new entity.Entity();
    camera.AddComponent(
        new first_person_camera.FirstPersonCamera({
            camera: this._camera,
            target: this._entityManager.Get('player')}));
    this._entityManager.Add(camera, 'player-camera');

  }
  */

  _OnWindowResize() {
    this._camera.aspect = window.innerWidth / window.innerHeight;
    this._camera.updateProjectionMatrix();
    this._threejs.setSize(window.innerWidth, window.innerHeight);
  }
  _RAF() {
    requestAnimationFrame((t) => {
      if (this._previousRAF === null) {
        this._previousRAF = t;
      }

      this._RAF();

      this._threejs.render(this._scene, this._camera);
      this._Step(t - this._previousRAF);
      this._previousRAF = t;
    });
  }

  _Step(timeElapsed) {
    const timeElapsedS = Math.min(1.0 / 30.0, timeElapsed * 0.001);

    const player = this._entityManager.Get('player');
    const pos = player._position;
  
    this._entityManager.Update(timeElapsedS);
  }
}

let _APP = null;

window.addEventListener('DOMContentLoaded', () => {
  _APP = new InLovingMemoryDemo();
});
